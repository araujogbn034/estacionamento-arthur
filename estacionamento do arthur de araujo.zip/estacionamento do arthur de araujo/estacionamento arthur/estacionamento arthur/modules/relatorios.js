export function gerarRelatorioCompleto() {
  const container = document.getElementById('relatorio-container');
  let html = `<h3>Relatório Geral</h3>`;
  html += `<p><strong>Total de Clientes:</strong> ${clientes.length}</p>`;
  html += `<p><strong>Veículos Cadastrados:</strong> ${veiculos.length}</p>`;
  html += `<p><strong>Veículos Estacionados Agora:</strong> ${estacionados.length}</p>`;
  container.innerHTML = html;
}