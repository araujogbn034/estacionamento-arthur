let clientes = [];

export function cadastrarCliente(cliente) {
  clientes.push(cliente);
  localStorage.setItem('clientes_estacionamento', JSON.stringify(clientes));
}

export function listarClientes() {
  const container = document.getElementById('lista-clientes');
  container.innerHTML = '<h3>Clientes Cadastrados:</h3>';
  clientes.forEach(c => {
    container.innerHTML += `
      <p><strong>${c.nome}</strong> - CPF: ${c.cpf} | Tel: ${c.telefone} | RG: ${c.rg}</p>
    `;
  });
}

export function carregarClientes() {
  const dados = localStorage.getItem('clientes_estacionamento');
  if (dados) clientes = JSON.parse(dados);
}