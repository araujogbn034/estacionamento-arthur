export let vagas = {
  total: 120,
  normais: 90,
  especiais: 20,
  vip: 10,
  ocupadas: 0
};

export function atualizarVagas() {
  const container = document.getElementById('vagas-container');
  container.innerHTML = `
    <p><strong>Total de Vagas:</strong> ${vagas.total}</p>
    <p><strong>Normais Disponíveis:</strong> ${vagas.normais - vagas.ocupadas}</p>
    <p><strong>Especiais (PCD):</strong> ${vagas.especiais}</p>
    <p><strong>VIP:</strong> ${vagas.vip}</p>
    <p><strong>Ocupadas:</strong> ${vagas.ocupadas}</p>
  `;
}