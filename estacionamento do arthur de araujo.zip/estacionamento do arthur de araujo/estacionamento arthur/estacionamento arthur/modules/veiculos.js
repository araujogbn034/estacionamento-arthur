let veiculos = [];

export function cadastrarVeiculo(cpf, dadosVeiculo) {
  const veiculo = {
    id: Date.now(),
    cpf,
    placa: dadosVeiculo.placa.toUpperCase(),
    marca: dadosVeiculo.marca,
    modelo: dadosVeiculo.modelo,
    ano: parseInt(dadosVeiculo.ano),
    cor: dadosVeiculo.cor,
    tamanho: dadosVeiculo.tamanho,
    dataCadastro: new Date().toISOString()
  };
  veiculos.push(veiculo);
  localStorage.setItem('veiculos_estacionamento', JSON.stringify(veiculos));
  return veiculo;
}

export function buscarVeiculosPorCpf(cpf) {
  return veiculos.filter(v => v.cpf === cpf);
}

export function carregarVeiculos() {
  const dados = localStorage.getItem('veiculos_estacionamento');
  if (dados) veiculos = JSON.parse(dados);
}

export function renderizarVeiculosDoCliente(cpf, containerId) {
  const container = document.getElementById(containerId);
  const veiculosCliente = buscarVeiculosPorCpf(cpf);
  
  if (veiculosCliente.length === 0) {
    container.innerHTML = "<p>Nenhum veículo cadastrado.</p>";
    return;
  }

  let html = "<h4>Veículos:</h4><ul>";
  veiculosCliente.forEach(v => {
    html += `<li><strong>${v.placa}</strong> - ${v.marca} ${v.modelo} (${v.ano}) | ${v.cor} | ${v.tamanho}</li>`;
  });
  html += "</ul>";
  container.innerHTML = html;
}