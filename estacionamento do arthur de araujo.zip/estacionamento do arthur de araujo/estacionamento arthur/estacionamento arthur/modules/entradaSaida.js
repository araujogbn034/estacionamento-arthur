let estacionados = [];

export function registrarEntrada(placa) {
  estacionados.push({
    placa: placa.toUpperCase(),
    entrada: new Date(),
    cpf: "pendente"
  });
  localStorage.setItem('estacionados', JSON.stringify(estacionados));
}

export function registrarSaida(placa) {
  const index = estacionados.findIndex(v => v.placa === placa.toUpperCase());
  if (index === -1) return null;

  const veiculo = estacionados[index];
  const saida = new Date();
  const tempoHoras = (saida - veiculo.entrada) / (1000 * 60 * 60);

  estacionados.splice(index, 1);
  localStorage.setItem('estacionados', JSON.stringify(estacionados));

  return { tempoHoras, placa: veiculo.placa };
}

export function listarEstacionados() {
  const container = document.getElementById('lista-estacionados');
  container.innerHTML = "<h3>Veículos Estacionados:</h3>";
  estacionados.forEach(v => {
    container.innerHTML += `<p>🚗 ${v.placa} - Entrada: ${new Date(v.entrada).toLocaleString()}</p>`;
  });
}

export function carregarEstacionados() {
  const dados = localStorage.getItem('estacionados');
  if (dados) estacionados = JSON.parse(dados);
}