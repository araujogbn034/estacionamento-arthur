export function calcularPreco(horas) {
  if (horas <= 24) return (horas * 10).toFixed(2);        // Hora
  if (horas <= 720) return 240;                           // Diária
  return 550;                                             // Mensal
}